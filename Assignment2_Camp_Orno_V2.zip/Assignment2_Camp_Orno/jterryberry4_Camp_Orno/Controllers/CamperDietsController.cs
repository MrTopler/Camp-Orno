﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using jterryberry4_Camp_Orno.Data;
using jterryberry4_Camp_Orno.Models;

namespace jterryberry4_Camp_Orno.Controllers
{
    public class CamperDietsController : Controller
    {
        private readonly CampContext _context;

        public CamperDietsController(CampContext context)
        {
            _context = context;
        }

        // GET: CamperDiets
        public async Task<IActionResult> Index()
        {
            var campContext = _context.CamperDiet.Include(c => c.Camper).Include(c => c.DietaryRestriction);
            return View(await campContext.ToListAsync());
        }

        // GET: CamperDiets/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var camperDiet = await _context.CamperDiet
                .Include(c => c.Camper)
                .Include(c => c.DietaryRestriction)
                .FirstOrDefaultAsync(m => m.CamperID == id);
            if (camperDiet == null)
            {
                return NotFound();
            }

            return View(camperDiet);
        }

        // GET: CamperDiets/Create
        public IActionResult Create()
        {
            ViewData["CamperID"] = new SelectList(_context.Camper, "ID", "Email");
            ViewData["DietaryRestrictionID"] = new SelectList(_context.DietaryRestriction, "ID", "Name");
            return View();
        }

        // POST: CamperDiets/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CamperID,DietaryRestrictionID")] CamperDiet camperDiet)
        {
            if (ModelState.IsValid)
            {
                _context.Add(camperDiet);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["CamperID"] = new SelectList(_context.Camper, "ID", "Email", camperDiet.CamperID);
            ViewData["DietaryRestrictionID"] = new SelectList(_context.DietaryRestriction, "ID", "Name", camperDiet.DietaryRestrictionID);
            return View(camperDiet);
        }

        // GET: CamperDiets/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var camperDiet = await _context.CamperDiet.FindAsync(id);
            if (camperDiet == null)
            {
                return NotFound();
            }
            ViewData["CamperID"] = new SelectList(_context.Camper, "ID", "Email", camperDiet.CamperID);
            ViewData["DietaryRestrictionID"] = new SelectList(_context.DietaryRestriction, "ID", "Name", camperDiet.DietaryRestrictionID);
            return View(camperDiet);
        }

        // POST: CamperDiets/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CamperID,DietaryRestrictionID")] CamperDiet camperDiet)
        {
            if (id != camperDiet.CamperID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(camperDiet);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CamperDietExists(camperDiet.CamperID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["CamperID"] = new SelectList(_context.Camper, "ID", "Email", camperDiet.CamperID);
            ViewData["DietaryRestrictionID"] = new SelectList(_context.DietaryRestriction, "ID", "Name", camperDiet.DietaryRestrictionID);
            return View(camperDiet);
        }

        // GET: CamperDiets/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var camperDiet = await _context.CamperDiet
                .Include(c => c.Camper)
                .Include(c => c.DietaryRestriction)
                .FirstOrDefaultAsync(m => m.CamperID == id);
            if (camperDiet == null)
            {
                return NotFound();
            }

            return View(camperDiet);
        }

        // POST: CamperDiets/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var camperDiet = await _context.CamperDiet.FindAsync(id);
            _context.CamperDiet.Remove(camperDiet);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CamperDietExists(int id)
        {
            return _context.CamperDiet.Any(e => e.CamperID == id);
        }
    }
}
