﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using jterryberry4_Camp_Orno.Data;
using jterryberry4_Camp_Orno.Models;

namespace jterryberry4_Camp_Orno.Controllers
{
    public class CompoundsController : Controller
    {
        private readonly CampContext _context;

        public CompoundsController(CampContext context)
        {
            _context = context;
        }

        // GET: Compounds
        public async Task<IActionResult> Index()
        {
            return View(await _context.Compound.ToListAsync());
        }

        // GET: Compounds/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var compound = await _context.Compound
                .FirstOrDefaultAsync(m => m.ID == id);
            if (compound == null)
            {
                return NotFound();
            }

            return View(compound);
        }

        // GET: Compounds/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Compounds/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,Name")] Compound compound)
        {
            if (ModelState.IsValid)
            {
                _context.Add(compound);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(compound);
        }

        // GET: Compounds/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var compound = await _context.Compound.FindAsync(id);
            if (compound == null)
            {
                return NotFound();
            }
            return View(compound);
        }

        // POST: Compounds/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,Name")] Compound compound)
        {
            if (id != compound.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(compound);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CompoundExists(compound.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(compound);
        }

        // GET: Compounds/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var compound = await _context.Compound
                .FirstOrDefaultAsync(m => m.ID == id);
            if (compound == null)
            {
                return NotFound();
            }

            return View(compound);
        }

        // POST: Compounds/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var compound = await _context.Compound.FindAsync(id);
            _context.Compound.Remove(compound);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CompoundExists(int id)
        {
            return _context.Compound.Any(e => e.ID == id);
        }
    }
}
