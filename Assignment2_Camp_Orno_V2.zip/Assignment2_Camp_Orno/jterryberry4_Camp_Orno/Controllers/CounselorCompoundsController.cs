﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using jterryberry4_Camp_Orno.Data;
using jterryberry4_Camp_Orno.Models;

namespace jterryberry4_Camp_Orno.Controllers
{
    public class CounselorCompoundsController : Controller
    {
        private readonly CampContext _context;

        public CounselorCompoundsController(CampContext context)
        {
            _context = context;
        }

        // GET: CounselorCompounds
        public async Task<IActionResult> Index()
        {
            var campContext = _context.CounselorCompound.Include(c => c.Compound).Include(c => c.Counselor);
            return View(await campContext.ToListAsync());
        }

        // GET: CounselorCompounds/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var counselorCompound = await _context.CounselorCompound
                .Include(c => c.Compound)
                .Include(c => c.Counselor)
                .FirstOrDefaultAsync(m => m.CounselorID == id);
            if (counselorCompound == null)
            {
                return NotFound();
            }

            return View(counselorCompound);
        }

        // GET: CounselorCompounds/Create
        public IActionResult Create()
        {
            ViewData["CompoundID"] = new SelectList(_context.Compound, "ID", "Name");
            ViewData["CounselorID"] = new SelectList(_context.Counselor, "ID", "FirstName");
            return View();
        }

        // POST: CounselorCompounds/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CounselorID,CompoundID")] CounselorCompound counselorCompound)
        {
            if (ModelState.IsValid)
            {
                _context.Add(counselorCompound);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["CompoundID"] = new SelectList(_context.Compound, "ID", "Name", counselorCompound.CompoundID);
            ViewData["CounselorID"] = new SelectList(_context.Counselor, "ID", "FirstName", counselorCompound.CounselorID);
            return View(counselorCompound);
        }

        // GET: CounselorCompounds/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var counselorCompound = await _context.CounselorCompound.FindAsync(id);
            if (counselorCompound == null)
            {
                return NotFound();
            }
            ViewData["CompoundID"] = new SelectList(_context.Compound, "ID", "Name", counselorCompound.CompoundID);
            ViewData["CounselorID"] = new SelectList(_context.Counselor, "ID", "FirstName", counselorCompound.CounselorID);
            return View(counselorCompound);
        }

        // POST: CounselorCompounds/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CounselorID,CompoundID")] CounselorCompound counselorCompound)
        {
            if (id != counselorCompound.CounselorID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(counselorCompound);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CounselorCompoundExists(counselorCompound.CounselorID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["CompoundID"] = new SelectList(_context.Compound, "ID", "Name", counselorCompound.CompoundID);
            ViewData["CounselorID"] = new SelectList(_context.Counselor, "ID", "FirstName", counselorCompound.CounselorID);
            return View(counselorCompound);
        }

        // GET: CounselorCompounds/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var counselorCompound = await _context.CounselorCompound
                .Include(c => c.Compound)
                .Include(c => c.Counselor)
                .FirstOrDefaultAsync(m => m.CounselorID == id);
            if (counselorCompound == null)
            {
                return NotFound();
            }

            return View(counselorCompound);
        }

        // POST: CounselorCompounds/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var counselorCompound = await _context.CounselorCompound.FindAsync(id);
            _context.CounselorCompound.Remove(counselorCompound);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CounselorCompoundExists(int id)
        {
            return _context.CounselorCompound.Any(e => e.CounselorID == id);
        }
    }
}
