﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using jterryberry4_Camp_Orno.Data;
using jterryberry4_Camp_Orno.Models;

namespace jterryberry4_Camp_Orno.Controllers
{
    public class CounselorsController : Controller
    {
        private readonly CampContext _context;

        public CounselorsController(CampContext context)
        {
            _context = context;
        }

        // GET: Counselors
        public async Task<IActionResult> Index()
        {
            return View(await _context.Counselor.ToListAsync());
        }

        // GET: Counselors/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var counselor = await _context.Counselor
                .FirstOrDefaultAsync(m => m.ID == id);
            if (counselor == null)
            {
                return NotFound();
            }

            return View(counselor);
        }

        // GET: Counselors/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Counselors/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,FirstName,MiddleName,LastName,NickName,SIN")] Counselor counselor)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _context.Add(counselor);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
            }
            catch (Exception ex)
            {
                if (ex.InnerException.Message.Contains("IX_Counselor_SIN"))
                    ModelState.AddModelError("", "Sin already in use");
                else
                    ModelState.AddModelError("", "Database Error");
            }
            return View(counselor);
        }

        // GET: Counselors/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var counselor = await _context.Counselor.FindAsync(id);
            if (counselor == null)
            {
                return NotFound();
            }
            return View(counselor);
        }

        // POST: Counselors/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,FirstName,MiddleName,LastName,NickName,SIN")] Counselor counselor)
        {
            if (id != counselor.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(counselor);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CounselorExists(counselor.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                catch (Exception ex)
                {
                    if (ex.InnerException.Message.Contains("IX_Counselor_SIN"))
                        ModelState.AddModelError("", "Sin already in use");
                    else
                        ModelState.AddModelError("", "Database Error");
                }
                return RedirectToAction(nameof(Index));
            }
            return View(counselor);
        }

        // GET: Counselors/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var counselor = await _context.Counselor
                .FirstOrDefaultAsync(m => m.ID == id);
            if (counselor == null)
            {
                return NotFound();
            }

            return View(counselor);
        }

        // POST: Counselors/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var counselor = await _context.Counselor.FindAsync(id);
            try
            {
                _context.Counselor.Remove(counselor);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {

                if (ex.InnerException.Message.Contains("FK_Camper_Counselor_CounselorID"))
                    ModelState.AddModelError("", "Unable to Delete Counslor Assigned to a Camper");
                if(ex.InnerException.Message.Contains("FK_CounselorCompound_Counselor_CounselorID"))
                    ModelState.AddModelError("", "Unable to Delete Counslor Assigned to a Compound");
                else
                    ModelState.AddModelError("", "Database Error, Please try again.");
            }
            return View(counselor);

        }

        private bool CounselorExists(int id)
        {
            return _context.Counselor.Any(e => e.ID == id);
        }
    }
}
