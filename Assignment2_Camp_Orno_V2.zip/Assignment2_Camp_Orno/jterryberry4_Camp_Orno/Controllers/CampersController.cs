﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using jterryberry4_Camp_Orno.Data;
using jterryberry4_Camp_Orno.Models;
using jterryberry4_Camp_Orno.ViewModels;

namespace jterryberry4_Camp_Orno.Controllers
{
    public class CampersController : Controller
    {
        private readonly CampContext _context;

        public CampersController(CampContext context)
        {
            _context = context;
        }

        // GET: Campers
        public async Task<IActionResult> Index()
        {
            var campContext = _context.Camper.Include(c => c.Compound).Include(c => c.Counselor);
            return View(await campContext.ToListAsync());
        }

        // GET: Campers/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var camper = await _context.Camper
                .Include(c => c.Compound)
                .Include(c => c.Counselor)
                .FirstOrDefaultAsync(m => m.ID == id);
            if (camper == null)
            {
                return NotFound();
            }

            return View(camper);
        }

        // GET: Campers/Create
        public IActionResult Create()
        {
            ViewData["CompoundID"] = new SelectList(_context.Compound, "ID", "Name");
            ViewData["CounselorID"] = new SelectList(_context.Counselor, "ID", "FirstName");
            Camper camper = new Camper();
            camper.CamperDiets = new List<CamperDiet>();
            PopulateAssignedDietData(camper);
            return View();
        }

        // POST: Campers/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,FirstName,MiddleName,LastName,DOB,Gender,Email,EmergencyPhone, CompoundID, CounselorID")] Camper camper, string[] selectedDiets)//added camper & selectedDiets part of checkboxes
        {
            try
            {
                if (selectedDiets != null)
                {
                    camper.CamperDiets = new List<CamperDiet>();
                    foreach (var diet in selectedDiets)
                    {
                        var dietToAdd = new CamperDiet { CamperID = camper.ID, DietaryRestrictionID = int.Parse(diet) };
                        camper.CamperDiets.Add(dietToAdd);
                    }
                }
                if (ModelState.IsValid)
                {
                    _context.Add(camper);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                PopulateAssignedDietData(camper);//Added
            }
            catch (Exception ex)
            {
                if (ex.InnerException.Message.Contains("IX_Camper_Email"))
                    ModelState.AddModelError("", "Email already in use");
                else
                    ModelState.AddModelError("", "Database Error! Please try again");
            }
            ViewData["CompoundID"] = new SelectList(_context.Compound, "ID", "Name", camper.CompoundID);
            ViewData["CounselorID"] = new SelectList(_context.Counselor, "ID", "FirstName", camper.CounselorID);
            PopulateAssignedDietData(camper);
            return View(camper);
        }

        // GET: Campers/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var camper = await _context.Camper
                .Include(p => p.Counselor)
                .Include(p => p.Compound)
                .Include(p => p.CamperDiets).ThenInclude(p => p.DietaryRestriction)
                .AsNoTracking()
                .SingleOrDefaultAsync(p => p.ID == id);
            if (camper == null)
            {
                return NotFound();
            }
            ViewData["CompoundID"] = new SelectList(_context.Compound, "ID", "Name", camper.CompoundID);
            ViewData["CounselorID"] = new SelectList(_context.Counselor, "ID", "FirstName", camper.CounselorID);
            PopulateAssignedDietData(camper);
            return View(camper);
        }

        // POST: Campers/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, string[] selectedDiets)
        {
            var camperToUpdate = await _context.Camper
                .Include(p => p.Counselor)
                .Include(p => p.Compound)
                .Include(p => p.CamperDiets).ThenInclude(p => p.DietaryRestriction)
                .AsNoTracking()
                .SingleOrDefaultAsync(p => p.ID == id);

            UpdateCamperDiets(selectedDiets, camperToUpdate);

            if (await TryUpdateModelAsync<Camper>(camperToUpdate, "",
                c => c.FirstName, c => c.MiddleName, c => c.LastName, c => c.Gender, c => c.Email, c => c.DOB, c => c.EmergencyPhone, c => c.CounselorID, c => c.CompoundID))
            {
                try
                {
                    _context.Update(camperToUpdate);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CamperExists(camperToUpdate.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                catch (DbUpdateException ex)
                {
                    if (ex.InnerException.Message.Contains("IX_Camper_Email"))
                        ModelState.AddModelError("", "Email already in use");
                    else
                        ModelState.AddModelError("", ex.InnerException.Message);
                }
            }
            ViewData["CompoundID"] = new SelectList(_context.Compound, "ID", "Name", camperToUpdate.CompoundID);
            ViewData["CounselorID"] = new SelectList(_context.Counselor, "ID", "FirstName", camperToUpdate.CounselorID);
            PopulateAssignedDietData(camperToUpdate);
            return View(camperToUpdate);
        }

        // GET: Campers/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var camper = await _context.Camper
                .Include(c => c.Compound)
                .Include(c => c.Counselor)
                .FirstOrDefaultAsync(m => m.ID == id);
            if (camper == null)
            {
                return NotFound();
            }

            return View(camper);
        }

        // POST: Campers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            try
            {
                var camper = await _context.Camper.FindAsync(id);
                _context.Camper.Remove(camper);
                await _context.SaveChangesAsync();
            }
            catch (Exception)
            {

                ModelState.AddModelError("", "Database Error! Please try again");
            }
            return RedirectToAction(nameof(Index));
        }

        private bool CamperExists(int id)
        {
            return _context.Camper.Any(e => e.ID == id);
        }
        private void PopulateAssignedDietData(Camper camper)
        {
            var allDiets = _context.DietaryRestriction;
            var cDiets = new HashSet<int>(camper.CamperDiets.Select(b => b.DietaryRestrictionID));
            var viewModel = new List<AssignedDietsVM>();

            foreach (var diet in allDiets)
            {
                viewModel.Add(new AssignedDietsVM
                {
                    DietaryRestrictionID = diet.ID,
                    DietaryRestrictionName = diet.Name,
                    Assigned = cDiets.Contains(diet.ID)
                });
            }
            ViewData["DietaryRestrictions"] = viewModel;
        }

        private void UpdateCamperDiets(string[] selectedDiets, Camper camperToUpdate)
        {
            if (selectedDiets == null)
            {
                camperToUpdate.CamperDiets = new List<CamperDiet>();
                return;
            }
            var selectedDietsHS = new HashSet<string>(selectedDiets);
            var camperds = new HashSet<int>
                (camperToUpdate.CamperDiets.Select(c => c.DietaryRestrictionID));
            foreach (var diet in _context.DietaryRestriction)
            {
                if (selectedDietsHS.Contains(diet.ID.ToString()))
                {
                    if (!camperds.Contains(diet.ID))
                    {
                        camperToUpdate.CamperDiets.Add(new CamperDiet { CamperID = camperToUpdate.ID, DietaryRestrictionID = diet.ID });
                    }
                }
                else
                {
                    if (camperds.Contains(diet.ID))
                    {
                        CamperDiet conditionToRemove = camperToUpdate.CamperDiets.SingleOrDefault(c => c.DietaryRestrictionID == diet.ID);
                        _context.Remove(conditionToRemove);
                    }
                }
            }
        }
    }
}
