﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using jterryberry4_Camp_Orno.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace jterryberry4_Camp_Orno.Data
{
    public static class CASeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {

            using (var context = new CampContext(
                serviceProvider.GetRequiredService<DbContextOptions<CampContext>>()))
            {

                if (!context.Camper.Any())
                {
                    context.Camper.AddRange(
                        new Camper
                        {
                            FirstName = "Fred",
                            MiddleName = "Reginald",
                            LastName = "Flintstone",
                            DOB = DateTime.Parse("1955-09-01"),
                            Gender = Gender.M,
                            Email = "FredReginaldsEmail@gmail.com",
                            EmergencyPhone = 9053584461
                        },
                        new Camper
                        {
                            FirstName = "Wilma",
                            MiddleName = "Jane",
                            LastName = "Flintstone",
                            DOB = DateTime.Parse("1964-04-23"),
                            Gender = Gender.F,
                            Email = "WilmaJanesEmail@gmail.com",
                            EmergencyPhone = 9053589956
                        },
                        new Camper
                        {
                            FirstName = "Barney",
                            LastName = "Rubble",
                            DOB = DateTime.Parse("1964-02-22"),
                            Gender = Gender.O,
                            Email = "BarneyTheDino'sEmail@gmail.com",
                            EmergencyPhone = 4168529754
                        },
                        new Camper
                        {
                            FirstName = "Jane",
                            MiddleName = "Samantha",
                            LastName = "Doe",
                            Gender = Gender.T,
                            Email = "unknown@gmail",
                            EmergencyPhone = 9056247894
                        });
                    context.SaveChanges();
                }
                if (!context.DietaryRestriction.Any())
                {
                    context.DietaryRestriction.AddRange(
                        new DietaryRestriction
                        {
                            Name = "Vegan"
                        },
                        new DietaryRestriction
                        {
                            Name = "Vegetarian"
                        },
                        new DietaryRestriction
                        {
                            Name = "Gluten Free"
                        },
                        new DietaryRestriction
                        {
                            Name = "Cannibal"
                        });
                    context.SaveChanges();
                }
                if (!context.CamperDiet.Any())
                {
                    context.CamperDiet.AddRange(
                        new CamperDiet
                        {
                            CamperID = context.Camper.FirstOrDefault(c => c.Email == "FredReginaldsEmail@gmail.com").ID,
                            DietaryRestrictionID = context.DietaryRestriction.FirstOrDefault(c => c.Name == "Vegan").ID
                        },
                        new CamperDiet
                        {
                            CamperID = context.Camper.FirstOrDefault(c => c.Email == "unknown@gmail").ID,
                            DietaryRestrictionID = context.DietaryRestriction.FirstOrDefault(c => c.Name == "Gluten Free").ID
                        },
                        new CamperDiet
                        {
                            CamperID = context.Camper.FirstOrDefault(c => c.Email == "WilmaJanesEmail@gmail.com").ID,
                            DietaryRestrictionID = context.DietaryRestriction.FirstOrDefault(c => c.Name == "Cannibal").ID
                        },
                        new CamperDiet
                        {
                            CamperID = context.Camper.FirstOrDefault(c => c.Email == "FredReginaldsEmail@gmail.com").ID,
                            DietaryRestrictionID = context.DietaryRestriction.FirstOrDefault(c => c.Name == "Cannibal").ID
                        });
                    context.SaveChanges();
                }
                if (!context.Counselor.Any())
                {
                    context.Counselor.AddRange(
                        new Counselor
                        {
                            FirstName = "Peggy",
                            MiddleName = "Pro",
                            LastName = "Hill",
                            NickName = "Propain",
                            SIN = "123456789"
                        },
                        new Counselor
                        {
                            FirstName = "Mr",
                            MiddleName = ".",
                            LastName = "T",
                            NickName = "The T",
                            SIN = "987654321"
                        },
                        new Counselor
                        {
                            FirstName = "Thomas",
                            MiddleName = "M",
                            LastName = "The train",
                            NickName = "ChoChoo!",
                            SIN = "133700000"
                        });
                    context.SaveChanges();
                }
                if (!context.Compound.Any())
                {
                    context.Compound.AddRange(
                        new Compound
                        {
                            Name = "Bikini bottom"
                        },
                        new Compound
                        {
                            Name = "Sea biscuit"
                        },
                        new Compound
                        {
                            Name = "Sky City"
                        });
                    context.SaveChanges();
                }

                if (!context.CounselorCompound.Any())
                {
                    context.CounselorCompound.AddRange(
                        new CounselorCompound
                        {
                            CounselorID = context.Counselor.FirstOrDefault(c => c.FirstName == "Peggy").ID,
                            CompoundID = context.Compound.FirstOrDefault(c => c.Name == "Bikini bottom").ID
                        },
                        new CounselorCompound
                        {
                            CounselorID = context.Counselor.FirstOrDefault(c => c.FirstName == "Mr.").ID,
                            CompoundID = context.Compound.FirstOrDefault(c => c.Name == "Sea biscuit").ID
                        },
                        new CounselorCompound
                        {
                            CounselorID = context.Counselor.FirstOrDefault(c => c.FirstName == "Thomas").ID,
                            CompoundID = context.Compound.FirstOrDefault(c => c.Name == "Sky City").ID
                        });
                    context.SaveChanges();
                }
            }
        }
    }
}
