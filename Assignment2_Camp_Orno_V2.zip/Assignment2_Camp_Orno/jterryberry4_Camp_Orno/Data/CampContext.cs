﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using jterryberry4_Camp_Orno.Models;

namespace jterryberry4_Camp_Orno.Data
{
    public class CampContext : DbContext
    {
        public CampContext (DbContextOptions<CampContext> options)
            : base(options)
        {
        }

        public DbSet<jterryberry4_Camp_Orno.Models.Camper> Camper { get; set; }

        public DbSet<jterryberry4_Camp_Orno.Models.DietaryRestriction> DietaryRestriction { get; set; }

        public DbSet<jterryberry4_Camp_Orno.Models.CamperDiet> CamperDiet { get; set; }

        public DbSet<jterryberry4_Camp_Orno.Models.Counselor> Counselor { get; set; }

        public DbSet<jterryberry4_Camp_Orno.Models.Compound> Compound { get; set; }

        public DbSet<jterryberry4_Camp_Orno.Models.CounselorCompound> CounselorCompound { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasDefaultSchema("CA");

            modelBuilder.Entity<Camper>()
                .HasIndex(p => p.Email)
                .IsUnique();

            modelBuilder.Entity<Counselor>()
                .HasIndex(p => p.SIN)
                .IsUnique();

            modelBuilder.Entity<CamperDiet>()
                .HasKey(t => new { t.CamperID, t.DietaryRestrictionID });

            modelBuilder.Entity<CounselorCompound>()
                .HasKey(k => new { k.CounselorID, k.CompoundID });



            modelBuilder.Entity<DietaryRestriction>()
                .HasMany<CamperDiet>(d => d.CamperDiets)
                .WithOne(p => p.DietaryRestriction)
                .HasForeignKey(p => p.DietaryRestrictionID)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Counselor>()
                .HasMany<CounselorCompound>(c => c.CounselorCompounds)
                .WithOne(p => p.Counselor)
                .HasForeignKey(p => p.CounselorID)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Compound>()
                .HasMany<CounselorCompound>(c => c.CounselorCompounds)
                .WithOne(p => p.Compound)
                .HasForeignKey(p => p.CompoundID)
                .OnDelete(DeleteBehavior.Restrict);

        }




    }
}
