﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace jterryberry4_Camp_Orno.Migrations
{
    public partial class init : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "CA");

            migrationBuilder.CreateTable(
                name: "Compound",
                schema: "CA",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Name = table.Column<string>(maxLength: 20, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Compound", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Counselor",
                schema: "CA",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    FirstName = table.Column<string>(maxLength: 30, nullable: false),
                    MiddleName = table.Column<string>(maxLength: 30, nullable: true),
                    LastName = table.Column<string>(maxLength: 50, nullable: false),
                    NickName = table.Column<string>(maxLength: 50, nullable: true),
                    SIN = table.Column<string>(maxLength: 9, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Counselor", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "DietaryRestriction",
                schema: "CA",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Name = table.Column<string>(maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DietaryRestriction", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Camper",
                schema: "CA",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    FirstName = table.Column<string>(maxLength: 30, nullable: false),
                    MiddleName = table.Column<string>(maxLength: 30, nullable: true),
                    LastName = table.Column<string>(maxLength: 50, nullable: false),
                    DOB = table.Column<DateTime>(nullable: false),
                    Gender = table.Column<int>(nullable: false),
                    Email = table.Column<string>(nullable: false),
                    EmergencyPhone = table.Column<long>(nullable: false),
                    CompoundID = table.Column<int>(nullable: true),
                    CounselorID = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Camper", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Camper_Compound_CompoundID",
                        column: x => x.CompoundID,
                        principalSchema: "CA",
                        principalTable: "Compound",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Camper_Counselor_CounselorID",
                        column: x => x.CounselorID,
                        principalSchema: "CA",
                        principalTable: "Counselor",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "CounselorCompound",
                schema: "CA",
                columns: table => new
                {
                    CounselorID = table.Column<int>(nullable: false),
                    CompoundID = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CounselorCompound", x => new { x.CounselorID, x.CompoundID });
                    table.ForeignKey(
                        name: "FK_CounselorCompound_Compound_CompoundID",
                        column: x => x.CompoundID,
                        principalSchema: "CA",
                        principalTable: "Compound",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_CounselorCompound_Counselor_CounselorID",
                        column: x => x.CounselorID,
                        principalSchema: "CA",
                        principalTable: "Counselor",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "CamperDiet",
                schema: "CA",
                columns: table => new
                {
                    CamperID = table.Column<int>(nullable: false),
                    DietaryRestrictionID = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CamperDiet", x => new { x.CamperID, x.DietaryRestrictionID });
                    table.ForeignKey(
                        name: "FK_CamperDiet_Camper_CamperID",
                        column: x => x.CamperID,
                        principalSchema: "CA",
                        principalTable: "Camper",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_CamperDiet_DietaryRestriction_DietaryRestrictionID",
                        column: x => x.DietaryRestrictionID,
                        principalSchema: "CA",
                        principalTable: "DietaryRestriction",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Camper_CompoundID",
                schema: "CA",
                table: "Camper",
                column: "CompoundID");

            migrationBuilder.CreateIndex(
                name: "IX_Camper_CounselorID",
                schema: "CA",
                table: "Camper",
                column: "CounselorID");

            migrationBuilder.CreateIndex(
                name: "IX_Camper_Email",
                schema: "CA",
                table: "Camper",
                column: "Email",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_CamperDiet_DietaryRestrictionID",
                schema: "CA",
                table: "CamperDiet",
                column: "DietaryRestrictionID");

            migrationBuilder.CreateIndex(
                name: "IX_Counselor_SIN",
                schema: "CA",
                table: "Counselor",
                column: "SIN",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_CounselorCompound_CompoundID",
                schema: "CA",
                table: "CounselorCompound",
                column: "CompoundID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CamperDiet",
                schema: "CA");

            migrationBuilder.DropTable(
                name: "CounselorCompound",
                schema: "CA");

            migrationBuilder.DropTable(
                name: "Camper",
                schema: "CA");

            migrationBuilder.DropTable(
                name: "DietaryRestriction",
                schema: "CA");

            migrationBuilder.DropTable(
                name: "Compound",
                schema: "CA");

            migrationBuilder.DropTable(
                name: "Counselor",
                schema: "CA");
        }
    }
}
