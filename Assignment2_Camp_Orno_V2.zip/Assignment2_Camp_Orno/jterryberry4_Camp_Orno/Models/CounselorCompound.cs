﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace jterryberry4_Camp_Orno.Models
{
    public class CounselorCompound
    {
        [Required(ErrorMessage = "Conselor ID cannot be blank")]
        public int CounselorID { get; set; }
        public Counselor Counselor { get; set; }

        [Required(ErrorMessage = "Compound ID cannot be blank")]
        public int CompoundID { get; set; }
        public Compound Compound { get; set; }
    }
}
