﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace jterryberry4_Camp_Orno.Models
{

    public class Camper : IValidatableObject
    {
        public int ID { get; set; }

        [Required(ErrorMessage = "First name cannot be blank")]
        [StringLength(30, ErrorMessage = "Too Big!")]
        [Display(Name = "First")]
        public string FirstName { get; set; }

        [StringLength(30, ErrorMessage = "Too Big!")]
        [Display(Name = "Middle")]
        public string MiddleName { get; set; }

        [Required(ErrorMessage = "Last name cannot be blank")]
        [StringLength(50, ErrorMessage = "Too Big!")]
        [Display(Name = "Last")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Date of Birth cannot be blank")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Display(Name = "Date of Birth")]
        public DateTime DOB { get; set; }

        [Required(ErrorMessage = "Gender cannot be blank")]
        public Gender Gender { get; set; }

        [Required(ErrorMessage = "Email cannot be blank")]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required(ErrorMessage = "Emergency Phone cannot be blank")]
        [Display(Name = "Emergency Phone")]
        [DataType(DataType.PhoneNumber)]
        [DisplayFormat(DataFormatString = "{0:###-###-####}", ApplyFormatInEditMode = true)]
        public Int64 EmergencyPhone { get; set; }

        public ICollection<CamperDiet> CamperDiets { get; set; }

        public int? CompoundID { get; set; }
        public Compound Compound { get; set; }

        public int? CounselorID { get; set; }
        public Counselor Counselor { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (DOB > DateTime.Now.AddYears(-4))
                yield return new ValidationResult($"Camper must be 4 years or older.");
        }
    }
}
