﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace jterryberry4_Camp_Orno.Models
{
    public class Counselor
    {
        public int ID { get; set; }

        [Required(ErrorMessage = "First name cannot be blank")]
        [StringLength(30, ErrorMessage = "Too Big!")]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }

        [StringLength(30, ErrorMessage = "Too Big!")]
        [Display(Name = "Middle Name")]
        public string MiddleName { get; set; }

        [Required(ErrorMessage = "Last name cannot be blank")]
        [StringLength(50, ErrorMessage = "Too Big!")]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [StringLength(50, ErrorMessage = "Too Big!")]
        [Display(Name = "Nick Name")]
        public string NickName { get; set; }

        [Required(ErrorMessage = "SIN cannot be blank")]
        [StringLength(9, MinimumLength = 9, ErrorMessage = "SIN can only be 9 digits long")]
        public string SIN { get; set; }

        public string FullName
        {
            get
            {
                if (string.IsNullOrEmpty(NickName))
                    return FirstName + (string.IsNullOrEmpty(MiddleName) ? " " : MiddleName[0].ToString()) + " " + LastName;
                else
                    return NickName + " " + LastName;
            }
        }

        public ICollection<CounselorCompound> CounselorCompounds { get; set; }
        public ICollection<Camper> Campers { get; set; }
    }
}
