﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace jterryberry4_Camp_Orno.Models
{
    public class CamperDiet
    {
        [Required(ErrorMessage = "Camper ID cannot be blank")]
        public int CamperID { get; set; }
        public Camper Camper { get; set; }

        [Required(ErrorMessage = "Dietary ID cannot be blank")]
        public int DietaryRestrictionID { get; set; }
        public DietaryRestriction DietaryRestriction { get; set; }
    }
}
