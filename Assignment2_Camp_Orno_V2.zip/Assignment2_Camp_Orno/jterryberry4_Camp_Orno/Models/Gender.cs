﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace jterryberry4_Camp_Orno.Models
{
    public enum Gender
    {
        M,
        F,
        N,
        T,
        O
    }
}
