﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace jterryberry4_Camp_Orno.Models
{
    public class Compound
    {
        public int ID { get; set; }

        [Required(ErrorMessage = "Name cannot be blank")]
        [StringLength(20, ErrorMessage = "Too Big!")]
        public string Name { get; set; }

        public ICollection<CounselorCompound> CounselorCompounds { get; set; }
        public ICollection<Camper> Campers { get; set; }
    }
}
